/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuttifruttitest1;

/**
 *
 * @author Kevin
 */
public class Persona {
    String nombre,color,marcas;

    public Persona(String nombre, String color, String marcas) {
        this.nombre = nombre;
        this.color = color;
        this.marcas = marcas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarcas() {
        return marcas;
    }

    public void setMarcas(String marcas) {
        this.marcas = marcas;
    }
    
    
    
}
